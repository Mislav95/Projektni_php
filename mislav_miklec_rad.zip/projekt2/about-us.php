<?php 
	print '
	<h1>O nama</h1>
    <h2>24sata - Multimedija</h2>
    <video width="40%" controls poster="http://www.rantsports.com/nba/files/2015/11/0.jpg" >
      <source src="video/nba-history.mp4" type="video/mp4">
      Your browser does not support HTML5 video.
    </video>
 
    <h3>Televizija</h3>
	<p>24sata TV prva je hrvatska televizija koja prikazuje samo vijesti. Započela s emitiranjem 18. lipnja 2009. godine i dosad je privukla više od 450.000 gledatelja tjedno [11]. Dostupna je u više od 330.000 kućanstava putem MAXtv-a, Iskon.TV-a, B.net-a, Optime, Amisa i H1, a nazočna je i na internetskoj adresi www.24sata.tv. Jedina je televizija u Hrvatskoj koja 24 sata na dan emitira aktualne vijesti iz područja politike, gospodarstva, crne kronike, showbusinessa i sporta, kao i vremensku prognozu. U prosincu 2010. započelo je i emitiranje vijesti uživo, a zaštitna lica 24sata TV-a postali su voditelji, novinari i urednici Tihomir Ladišić i Nensi Blažević. U ožujku 2011. godine Tihomir Ladišić odlazi s funkcije glavnog urednika 24sata TV-a, na mjesto glavnog urednika dolazi njegova dotadašnja zamjenica Nensi Blažević. Nakon nekoliko mjeseci glavni urednik postaje Željko Ljubobratović.</p>';
?>