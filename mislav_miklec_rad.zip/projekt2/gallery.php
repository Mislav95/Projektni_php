<?php 
	print '
<h1>Galerija</h1>

<div class="gallery"  >
      <figure>
       <a target="_blank"href="https://specials-images.forbesimg.com/imageserve/5b153a1031358e612fbb0afb/416x416.jpg?background=000000&cropX1=642&cropX2=2255&cropY1=29&cropY2=1641"><img src="https://specials-images.forbesimg.com/imageserve/5b153a1031358e612fbb0afb/416x416.jpg?background=000000&cropX1=642&cropX2=2255&cropY1=29&cropY2=1641" width="200" height="200">
        <figcaption class="sch">
          <i>James Harden

</i>

</a>
        </figcaption>
      </figure>
      <figure>
        <a target="_blank" href="https://timedotcom.files.wordpress.com/2018/07/180702-lebron-james-lakers.jpg?quality=85"><img src="https://timedotcom.files.wordpress.com/2018/07/180702-lebron-james-lakers.jpg?quality=85" width="200" height="200">
        <figcaption class="bogda"><i>LeBron James</i></a></figcaption>
      </figure>
	  </figcaption>
      </figure>
      <figure>
	  
	  
	  
        <a target="_blank" href="https://cdn.vox-cdn.com/thumbor/GSmK_8f5Qn-5_Vjnw_rHYGVJfTw=/0x0:5197x3575/1200x800/filters:focal(2184x1373:3014x2203)/cdn.vox-cdn.com/uploads/chorus_image/image/57034459/usa_today_10307530.0.jpg"> <img src="https://cdn.vox-cdn.com/thumbor/GSmK_8f5Qn-5_Vjnw_rHYGVJfTw=/0x0:5197x3575/1200x800/filters:focal(2184x1373:3014x2203)/cdn.vox-cdn.com/uploads/chorus_image/image/57034459/usa_today_10307530.0.jpg" width="200" height="200">
        <figcaption class="bogda"><i>Dario Šarić</i></a></figcaption>
      </figure>
	  </figcaption>
      </figure>
      <figure>
        <a target="_blank" href="https://usatftw.files.wordpress.com/2018/05/usp-nba_-minnesota-timberwolves-at-philadelphia-76_98698884-e1527299798219.jpg?w=1000&h=600&crop=1"><img src="https://usatftw.files.wordpress.com/2018/05/usp-nba_-minnesota-timberwolves-at-philadelphia-76_98698884-e1527299798219.jpg?w=1000&h=600&crop=1" width="200" height="200">
        <figcaption class="bogda"><i>Joel Embiid</i></a></figcaption>
      </figure>
	  </figcaption>
      </figure>
      <figure>
        <a target="_blank" href="https://static.klix.ba/media/images/vijesti/b_171126004.jpg"><img src="https://static.klix.ba/media/images/vijesti/b_171126004.jpg" width="200" height="200">
        <figcaption class="bogda"><i>Jusuf Nurkić</i></a></figcaption>
      </figure>
	  </figcaption>
      </figure>
	  </div>
	  <div class="gallery">
      <figure>
        <a target="_blank" href="http://www2.pictures.zimbio.com/gi/Bojan+Bogdanovic+-eX0CVXTnWvm.jpg"><img src="http://www2.pictures.zimbio.com/gi/Bojan+Bogdanovic+-eX0CVXTnWvm.jpg" width="200" height="200">
        <figcaption class="bogda"><i>Bojan Bogdanovic</i></a></figcaption>
      </figure>
	  </figcaption>
      </figure>
      <figure>
        <a target="_blank" href="http://image.masslive.com/home/mass-media/width600/img/celtics_impact/photo/jayson-tatum-123ad132cfb33a0c.jpg"><img src="http://image.masslive.com/home/mass-media/width600/img/celtics_impact/photo/jayson-tatum-123ad132cfb33a0c.jpg" width="200" height="200">
        <figcaption class="bogda"><i>Jayson Tatum</i></a></figcaption>
      </figure>
	  </figcaption>
      </figure>
      <figure>
        <a target="_blank" href="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Isaiah_Thomas_Dec_2013.jpg/220px-Isaiah_Thomas_Dec_2013.jpg"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Isaiah_Thomas_Dec_2013.jpg/220px-Isaiah_Thomas_Dec_2013.jpg" width="200" height="200">
        <figcaption class="bogda"><i>Isaih Thomas</i></a></figcaption>
      </figure>
	  </figcaption>
      </figure>
      <figure>
        <a target="_blank" href="https://usathoopshype.files.wordpress.com/2018/09/gettyimages-1015645490.jpg?w=1000&h=600&crop=1"><img src="https://usathoopshype.files.wordpress.com/2018/09/gettyimages-1015645490.jpg?w=1000&h=600&crop=1" width="200" height="200">
        <figcaption class="bogda"><i>Luka Dončić</i></a></figcaption>
      </figure>
	  </figcaption>
      </figure>
      <figure>
        <a target="_blank" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQd5EpwO9I48hcfl5Nlt446JqRGJX-4vllW_m0drEHJwdiPu9u7"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQd5EpwO9I48hcfl5Nlt446JqRGJX-4vllW_m0drEHJwdiPu9u7" width="200" height="200">
        <figcaption class="bogda"><i>Dzanan Musa</i></a></figcaption>
      </figure>
    </div>
	 '
	?>
