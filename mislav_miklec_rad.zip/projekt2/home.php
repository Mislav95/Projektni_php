<?php 
	print '
	<h1>24 sata</h1>
	<figure>
		<img src="https://www.24sata.hr/static/img/logo.svg" alt="24" title="24">
		
	</figure>
	<p>24sata je multimedijalni brand koji je najprepoznatljiviji po dnevnim novinama u Hrvatskoj. Prema podatcima za 2011. prosječna prodana naklada iznosila je 130.500 primjeraka.[3] Dnevnik 24sata svaki dan pročita 910.000 ljudi.

Izdaje ga tvrtka 24sata d. o. o. koja je u 100 postotnom vlasništvu austrijskog izdavača Styria Media Group AG.</p>
        <p>Prvi broj dnevnika 24sata na kioske je izašao 2. ožujka 2005. godine. Nakon godinu dana postale su najčitanije dnevne novine u Hrvatskoj, a sljedeće godine postale su i najprodavanije. Prema podacima iz 2011. 24sata mjesečno se prodaje u prosječno 130.500 primjeraka [4] i ima čitanost od prosječno 910.000 čitatelja dnevno.[4] Danas se prodaju po cijeni od 5 kuna, a izdaju se u šest izdanja.</p>
        <p>Tvrtka 24sata d. o. o. (tada Media-Ideja d.o.o.) osnovana je potkraj 2004. godine i nalazi se u 100 postotnom vlasništvu austrijskog izdavača Styria Media Group AG, a prvi broj dnevnog lista 24sata izdan je 2. ožujka 2005. godine. Prvo razdoblje izlaženja obilježio je svojim uredničkim konceptom Matija Babić, a krajem 2005. godine uredničko je vodstvo preuzeo Boris Trupčević, koji kasnije odlazi u Upravu. Trenutačni glavni urednik novina je Goran Gavranović.

Tvrtka danas zapošljava oko 250 ljudi, prosječne dobi od 32 godine. 24sata suvlasnik je web portala Njuškalo (jedan od internetskih oglasnika) te foto-agencije Pixsell Media d. o. o.</p>
        <p>Besplatno popodnevno izdanje tiskalo se od travnja 2006. do sredine 2012. godine. Dijelilo se svaki radni dan na najfrekventnijim zagrebačkim ulicama.</p>
	';
?>