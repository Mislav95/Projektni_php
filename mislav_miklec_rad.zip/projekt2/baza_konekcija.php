<?php
	# Connect to MySQL database
	$MySQL = mysqli_connect("localhost","root","","webprog") or die('Error connecting to MySQL server.');